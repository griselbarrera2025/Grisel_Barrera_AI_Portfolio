# Large Language Models

## Problem Statement
Use pre-trained LLMs like BERT and GPT for advanced NLP tasks.

## Approach & Methodology
- Used HuggingFace Transformers
- Performed Q&A, summarization, translation

## Results & Evaluation
LLMs handled context-rich tasks effectively.

## Learning Outcomes
- LLM usage and prompt engineering

## Requirements
```
pip install transformers torch
```
