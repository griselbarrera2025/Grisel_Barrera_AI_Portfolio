# Text Representation Techniques

## Problem Statement
Text must be represented numerically for machine learning.

## Approach & Methodology
- Bag-of-Words
- TF-IDF
- Word2Vec and GloVe embeddings

## Results & Evaluation
Demonstrated representation differences and semantic similarity.

## Learning Outcomes
- Vectorization and embedding usage

## Requirements
```
pip install gensim scikit-learn
```
