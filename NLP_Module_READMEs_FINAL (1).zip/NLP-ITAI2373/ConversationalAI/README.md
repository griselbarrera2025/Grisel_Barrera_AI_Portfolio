# Conversational AI

## Problem Statement
Create AI agents that can hold contextual, goal-driven conversations.

## Approach & Methodology
- Rule-based bots with Rasa
- Neural chatbot using GPT

## Results & Evaluation
GPT provided contextual flexibility; Rasa was rule-precise.

## Learning Outcomes
- Dialog systems
- Intent classification and state management

## Requirements
```
pip install rasa transformers
```
