# Sentiment and Emotion Analysis

## Problem Statement
Understand user sentiment and emotional state from text.

## Approach & Methodology
- VADER and LSTM models
- Trained on IMDB and Twitter

## Results & Evaluation
LSTM outperformed rule-based methods on long text.

## Learning Outcomes
- Sentiment pipelines
- Emotion classification strategy

## Requirements
```
pip install vaderSentiment keras
```
