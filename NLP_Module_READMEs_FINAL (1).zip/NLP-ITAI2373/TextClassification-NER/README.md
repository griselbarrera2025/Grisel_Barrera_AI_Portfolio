# Text Classification and NER

## Problem Statement
Classify documents and identify entities like people, locations, etc.

## Approach & Methodology
- SVM for multi-class classification
- SpaCy and Transformers for NER

## Results & Evaluation
NER extracted key entities with high accuracy.

## Learning Outcomes
- Named entity pipelines
- Multi-class classification strategies

## Requirements
```
pip install spacy scikit-learn transformers
```
