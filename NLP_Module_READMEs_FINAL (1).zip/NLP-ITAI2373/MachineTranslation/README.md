# Machine Translation

## Problem Statement
Translate text across languages using neural models.

## Approach & Methodology
- MarianMT and mBART models from HuggingFace
- Evaluated with BLEU scores

## Results & Evaluation
High-quality translation performance

## Learning Outcomes
- Encoder-decoder architecture
- Sequence modeling

## Requirements
```
pip install transformers sacrebleu
```
