# Topic Modeling

## Problem Statement
Extract themes from large document collections.

## Approach & Methodology
- LDA and NMF algorithms
- Preprocessing using bigrams and lemmatization

## Results & Evaluation
Generated coherent topics and word clouds.

## Learning Outcomes
- Unsupervised learning for NLP
- Topic extraction techniques

## Requirements
```
pip install gensim pyLDAvis
```
