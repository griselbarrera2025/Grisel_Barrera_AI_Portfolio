# Part-of-Speech Tagging

## Problem Statement
Tagging grammatical parts of text enables deeper understanding.

## Approach & Methodology
- Used NLTK and spaCy for POS tagging
- Compared results across text types

## Results & Evaluation
Tagging accuracy varies by dataset cleanliness.

## Learning Outcomes
- POS tag interpretation and feature extraction

## Requirements
```
pip install nltk spacy
```
